---
name: ✨ Feature request
about: Suggest an idea for this project

---

##### SUMMARY
<!--- Explain the problem briefly -->


##### ISSUE TYPE
 - Feature Idea
